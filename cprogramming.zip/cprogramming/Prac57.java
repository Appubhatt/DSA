package cprogramming;

public class Prac57 {
    public static void main(String[] args) {

    }
}
